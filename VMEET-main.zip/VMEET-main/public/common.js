

var userName =  document.getElementById("indexTopRightUserNameInput").value
localStorage.setItem('myName', 'Tom');